# E-mail drafts

**Draft 1 (registration) was sent on 15 October 2026, 21:25.** It is kept below exactly as sent, and
recorded in `REGISTRATION.md`. Drafts 1b and 2 have **not** been sent: review each one, fill in the
brackets, and send from your own account. Check the address and the subject on the official site
before sending anything that contains passport pages.

## 1. Registration (SENT, 15 October 2026)

**To:** the organiser's registration contact (see `docs/COMPETITION_RULES.md`)
**Subject:** International Track Registration – TeamEkxin – Farhan Labib
**Attached:** the completed registration form, the passport bio pages of all four members, and proof of
enrolment (studentship certificates and student cards)

```
Dear Ms. WANG Yiran,

We would like to register for the 2026 Shenzhen International FinTech Competition – International Track.

Team name: TeamEkxin
Topic: C (Cross-border & Student Finance Assistant)
Entry title: StudyRoute
Team leader: Farhan Labib
Members: Md Redwan Hossen, Alim Bin Yeasin, Kalvin Chakma
University: Ahsanullah University of Science and Technology, Bangladesh

Attached are the completed registration form, the passport bio pages of all four members, and proof of enrollment (studentship certificates and student cards).

Please confirm receipt and our slot allocation. We look forward to your reply.

Best regards,
Farhan Labib
```

If no confirmation has arrived by the evening of 18 October, write again (draft 1b is a good base) and
ask for the slot to be confirmed.

## 1b. Eligibility question (send before registering if any of it is unclear)

Send this first if the team is unsure about the 60% rule or whether its universities qualify. It
contains no passport pages. Do not wait for the answer to prepare everything else; the deadline is
the same for registration and submission.

**To:** wangyr@pbcsf.tsinghua.edu.cn
**Subject:** International Track eligibility question - [Country] - [Team leader's full name]

```
Dear Ms. WANG Yiran,

We are preparing an entry for the International Track (Topic C) and would like to confirm two
points in the rules before we register.

1. The rules say the team needs "60% non-Chinese nationals, major, or year of study". Is the 60%
   counted by nationality of the team members? Our team has [number] members, [number] of them
   non-Chinese nationals.
2. All of our members are full-time students at [university, country]. Is a university in
   [country] eligible? We could not find a list of eligible countries, only the exclusions
   (Mainland China, Hong Kong SAR, Macao SAR and Chinese Taipei).

Thank you for your help.

Kind regards,
[team leader's full name]
TeamEkxin
```

## 2. Final submission

**To:** wangyr@pbcsf.tsinghua.edu.cn
**Subject:** `TeamEkxin - International Track - Topic C - Final submission` (use the organisers'
format if the rules or the form give one).
**Attach:** the mandatory items and the small optional ones, from the local `FINAL_SUBMISSION/` folder (about 4 MB in
all; see `submission/README_START_HERE.md`). **Link:** the demo video and the source (the archive is 82 MB: send the
GitHub link instead). The organiser's e-mail of 15 October asks for submissions as soon as
possible, so do not wait for the deadline.

```
Dear Ms. WANG Yiran,

Please find the final submission of team TeamEkxin for the International Track, Topic C:
Cross-border and Student Finance Assistant. The project is StudyRoute, a sandbox AI agent that
helps a parent in Bangladesh pay a student's tuition and living costs abroad. All data is
synthetic and no real money moves. The corridor is large and growing: Bangladesh Bank data show USD 881.7
million sent through banks for overseas education in 2025-26, a record and 32% more than a year earlier
(sources and our sums, with their limits, are in the technical documentation and docs/BUSINESS_CASE.md).

Mandatory, attached:
1. Technical documentation (architecture, core algorithms, security design):
   StudyRoute_Technical_Documentation.pdf
2. Presentation deck (10 minutes): StudyRoute_Deck.pptx

Optional:
3. Demo video (under 5 minutes): [link]
4. Source code with README, deployment instructions and test cases:
   GitHub: https://github.com/NoobCrow/StudyRoute
   Start: docker compose up --build, then http://localhost:8080
5. Security self-assessment report (permission tiers and known-risk list):
   StudyRoute_Security_Self_Assessment.pdf (attached)
6. Execution evidence (sandbox operation logs, audit log and verification, tamper and restore experiment,
   ledger and escrow checks): StudyRoute_Execution_Evidence_Report.pdf and StudyRoute_Evidence_Pack.zip
   (attached; the zip holds the raw logs, Word and Markdown editions and checksums); more in the repository
   under submission/evidence/.

Demo accounts and the one-command start are described in the README.

Kind regards,
[team leader's full name]
TeamEkxin
```
